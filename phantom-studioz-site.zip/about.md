# About Phantom studioZ
Phantom studioZ is a modern hair salon focused on African beauty.  
We specialize in ready-made wigs, hair care services, and slay-worthy transformations.
